#!/bin/bash

function __besman_install_dummy1
{
echo "installed dummy1"
}
